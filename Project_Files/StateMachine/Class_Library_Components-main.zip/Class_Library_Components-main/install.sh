#!/bin/bash

# stores library and headers in usr/local
cp libE4235.a /usr/local/lib
cp E4235.h /usr/local/include

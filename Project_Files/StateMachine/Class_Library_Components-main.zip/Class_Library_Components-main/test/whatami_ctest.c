#include <stdio.h>
#include "E4235.h"

// extern int whatami(int);

int main() {
    int ret = E4235_whatami(1);
    printf("%d\n", ret);
    return(0);
}


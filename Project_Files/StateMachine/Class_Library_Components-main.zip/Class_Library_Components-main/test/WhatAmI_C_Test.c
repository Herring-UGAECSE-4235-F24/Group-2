#include <stdio.h>
#include "E4235.h"

int main() {
    int freq = 0;
    freq = E4235_WhatAmI(); // gets frequency using WhatAmI
    printf("freq = %d\n", freq); // prints frequency to terminal
} // main
